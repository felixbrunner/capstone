# README

This repo is based on the LDSSA [Deploy to heroku](https://github.com/LDSSA/heroku-model-deploy) repository and serves to deploy the capstone project model.
